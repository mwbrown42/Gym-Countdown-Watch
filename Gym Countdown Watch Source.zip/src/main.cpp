// Super quick and dirty project to count from 0 to 60 when reset button pressed
// Display value on an OLED screen with SSD1306 controller chip, over I2C bus, 128x64 pixels

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Fonts/FreeSerif9pt7b.h>
#include <Fonts/FreeMonoBold24pt7b.h>
#include <Fonts/FreeSansBold24pt7b.h>
#include <Fonts/FreeSerifBold24pt7b.h>
#include <Arduino.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)

// Initialize the OLED display
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void setup()
{
  // Open serial port
  Serial.begin(115200);

  // Set up blinky
  pinMode(LED_BUILTIN, OUTPUT);

  // Set up I2C bus connection to OLED display
  // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;)
      ; // Don't proceed, loop forever
  }

  // Clear the buffer
  display.clearDisplay();

  // Initialize the screen text parameters
  // display.setFont(&FreeSerif9pt7b);
  display.setFont(&FreeMonoBold24pt7b);
  // display.setFont(&FreeSansBold24pt7b);
  // display.setFont(&FreeSerifBold24pt7b);
  display.setTextSize(2);
  display.setTextColor(WHITE); // Draw white text
  display.cp437(true);         // Use full 256 char 'Code Page 437' font
}

void loop() 
{
  int secondsLimit = 60;
  int blinkyState = LOW;

  for (int seconds = 0; seconds <= secondsLimit; seconds++)
  {
    // Flip blink
    blinkyState = !blinkyState;
    digitalWrite(LED_BUILTIN, blinkyState);

    // write out current value to the display
    display.clearDisplay();
    display.setCursor(10, 60);
    display.println(seconds);
    display.display();

    // delay for 1 second
    sleep(1);
  }
}